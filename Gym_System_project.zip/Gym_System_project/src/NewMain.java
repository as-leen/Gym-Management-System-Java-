


import static Main.fillList;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class NewMain {
static ArrayList<Member> list = new ArrayList<Member>();
 
    public static void main(String[] args) {
     
        Scanner input = new Scanner(System.in); 
        int choice = 0; 
    fillList();

System.out.println("*** WELCOME TO GYM SYSTEM ***"); 
        do { 
            try { 
                menu(); 
                choice = input.nextInt(); 
                switch (choice) { 
 case 1 ://be a member 

 System.out.print("1. Basic Membership \n"
                                + "2. Premium Membership  \n"
                                
                                + "Select type of the membership to add >> ");
 
                        int Type = input.nextInt();

if (Type < 1 || Type > 2) { 
                            System.out.println(" Invalid choice "); 
                        } else {
Member member ;
}


System.out.print("Enter Phone Number: "); 
                            int phoneNum = input.nextInt(); 
                            input.nextLine(); 
                            System.out.print("Enter subscription name:"); 
                            String name = input.nextLine(); 
                            System.out.print("Enter price per month:"); 
                            double priceMonth = input.nextDouble();

System.out.println("Enter your height : "); 
                                int heghit = input.nextInt();

System.out.println("Enter your weghit : "); 
                                int weghit = input.nextInt();

System.out.print("How many Item you want added? "); 
 
                            int numItem = input.nextInt(); 
                            Item[] item = new Benefit[numItem];

for (int i = 0; i < item.length; i++) {

input.nextLine(); 
                                
                                System.out.println("Enter item name: "); 
                                String itemname = input.next();

              System.out.print("Enter amount : "); 
                                int amount = input.nextInt();
 
                                input.nextLine(); 
                                System.out.print("Enter description: "); 
                                String description = input.nextLine();

item[i] = new Item(itemname, amount, description); 
 
                            }

System.out.print("Enter duration in month: "); 
                            int durationInMonth = input.nextInt(); 
                            
if (subscriptionType == 1) {
                                System.out.print("Enter max GYM accesstimes: ");
                                int maxAcc = input.nextInt();
                                Member = new (subscriptionId, name, pricePerMonth, benefits, durationInMonth, maxAcc);
}else {
                                //Trainer(String trainerId, String name, String mainSpecialization, int ID)
                                System.out.print("Enter trainerId: ");
                                int trainerId = input.nextInt();

                                System.out.print("Enter trainer name: ");
                                String trainerName = input.nextLine();
                                System.out.println("Enter main specialization: ");
                                String mainSpecialization = input.nextLine();

                                Member = new VIPSubscription(subscriptionId, name, pricePerMonth, benefits, durationInMonth, new Trainer(trainerId, name, mainSpecialization));
                                          list.add(Member);
                            System.out.println("subscription has been added to the list.");
                                         
}
break;
  case 2://Remove member
                        System.out.print("Enter member id to remove: ");
                        int Id = input.next();
                        boolean removed = false;
                        for (int i = 0; i < list.size(); i++) {
                            Member ele = list.get(i);
                            if (ele.getSubscriptionId().equals(subscriptionId)) {
                                list.remove(i);
                                removed = true;
                                break;
                            }
                        }//end loop
                        if (removed) {
                            System.out.println("member with id " + Id + " has been removed.");
                        } else {
                            System.out.println("No member with id " + Id + " is found.");
                        }
                        break;
  case 3://New Registration
                        System.out.printf("Enter member  id: ");
                        Id = input.next();
                       
                        Member sub = null;
                        boolean isFound = false;
                        for (Member ele : list) {
                            if (ele.getId().equals(Id)) {
                                sub = ele;
                                isFound = true;
                                break;
                            }
                        }
                        if (!isFound) {
                            System.out.println("Invalid member id!");
                            continue;
                        }
                        //end while loop
                        System.out.println("Enter Registration date:");
                        System.out.print("year: ");
                        int year = input.nextInt();
                        if (year < 2024) {
                            System.out.println("Invalid year.");
                            continue;
                        }
                        System.out.print("month: ");
                        int month = input.nextInt();
                        if (month < 1 || month > 12) {
                            System.out.println("Invalid month.");
                            continue;
                        }
                        System.out.print("day: ");
                        int day = input.nextInt();
                        if (day < 1 || day > 31) {
                            System.out.println("Invalid day.");
                            continue;
                        }

                        Date date = new Date(year, month, day);
                        //read Trainee info
                        System.out.print("Enter your id: ");
                        int id = input.nextInt();
                        input.nextLine();
                        System.out.print("Enter your name: ");
                        String name = input.nextLine();
                        System.out.print("Enter phone number: ");
                        String phoneNo = input.next();

                        System.out.print("Enter Height: ");
                        int height = input.nextInt();

                        System.out.print("Enter weight: ");
                        int weight = input.nextInt();
                        
                        
                        
case 4:
                        ArrayList<DietarySupplement> dietarySupplements = new ArrayList<>();

                        
                        //show the list
                        for (int i = 0; i < dietarySupplements.size(); i++) {
                            System.out.println(i + "-" + dietarySupplements.get(i));
                            System.out.println("----------------");
                        }
                        System.out.print("Enter the item index:");
                        int index = input.nextInt();
                        if (index < 0 || index >= dietarySupplements.size()) {
                            System.out.println("invalid index");
                            continue;
                        }

                        DietarySupplement item = dietarySupplements.get(index);

                        System.out.println(item);

                        item.pay();
                        System.out.println("Thanks for the order!");

                        break;
 case 3://Display memership
                        for (Member ele : list) {
                            // Polymorphic methods(Polymorphism)
                            System.out.println(ele);
                            System.out.printf("Membership Cost: %.2f%n", ele.calculate());

                            // Downcasting to call specific methods 
                            System.out.println("----------------------------");
                            if (ele instanceof Premium) {
                                System.out.println(((Premium) ele).getAdditionalPerks());
                            }
                            System.out.println("----------------------------");
                        }
                        break;













 case 8://GUI
                        //GUI.main(null); //calling static method
                        break;

                    case 9://Read from text file
                        ReadText rt = new ReadText();
                        rt.openTextFile("Member.txt");
                        rt.readFromFile();
                        rt.closeFile();
                        break;

                    case 10://Save/Write to text file
                        WriteText wf = new WriteText();
                        wf.openTextFile("subscription.txt");
                        if (list.isEmpty()) {
                            System.out.println("No orders yet.");
                        } else {
                            for (Member ele : list) {
                                wf.writeToFile(ele);
                            }
                        }
                        wf.closeFile();
                        System.out.println("All orders saved to the text file orders.txt");
                        break;

                    case 11://Exit
                        System.out.println("Thank you for using our system.\nHave a nice day.");
                        break;
                    default:
                        System.out.println("Invalid Choice!");
           
                }
            }catch (InputMismatchException ex) {
                System.err.println("Invalid input");
                input.nextLine();
            } catch (NullPointerException ex) {
                System.err.println(ex);
            } catch (ClassCastException ex) {
                System.err.println(ex);
            } catch (ArrayIndexOutOfBoundsException ex) {
                System.err.println(ex);
            } catch (Exception ex) {
                System.err.println(ex);
            }
        } while (choice != 8);

    }
    
public static void menu() {
        System.out.print("\n1. Add Membership . \n"
                + "2. Remove Membership .  .\n"
                + "3. Display Membership.\n"
                + "4. Order Dietary Supplement \n"
                + "5. GUI.\n"
                + "6. Read From File.\n"
                + "7.Save Orders.\n"
                + "8.Exit.\n"
                + ">> ");
    }
}


