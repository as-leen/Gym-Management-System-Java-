
public final class Date {
    private int year;
    private  int month ;
    private  int day ;

    public Date(int year, int month, int day) {
        setYear( year);
       setMonth( month);
        setDay( day);
    }

    public Date() {
        this (0,0,0);
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        if (year< 2024){
            System.out.println("The year is invalid!!");
        }else{
        this.year = year;
        }
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        if (month< 1 || month >12){
            System.out.println("The Month is invalid!!");
        }else{
        this.month = month;
        }
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
if (day< 1 || day >31){
            System.out.println("The Day is invalid");
        }else{
        this.day = day;
        }    }

    @Override
    public String toString() {
        return String.format (" %d/%d/%d ",getYear(), getMonth(), getDay());
    }
    
    
    
}
