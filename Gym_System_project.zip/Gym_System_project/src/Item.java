

public class Item {

private String name;

private int amount;

private String dwscription;

public Item (String name, int amount, String dwscription) {

this.name = name;

this.amount = amount;

this.dwscription = dwscription;

}

public Item() {
this ("" ,0,"");
}



public String getName() {

return name;

}

public void setName (String name) {

this.name = name;

}

public int getAmount () {

return amount; }

public void setAmount (int amount) {

this.amount = amount;

}
public String getDwscription() {

return dwscription;

}

public void setDwscription (String dwscription) {

this.dwscription = dwscription;

}

@Override

public String toString() {

return "Item(" + "name=" + name + ", amount=" + amount + ", dwscription=" + dwscription + '}';
 
}

}


