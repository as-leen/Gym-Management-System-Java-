
public class Trainer extends Person {
  private String Specialization;  

    public Trainer(int Id,String name, String Specialization ) {
        super(Id, name);
      setSpecialization( Specialization);
    }

    public Trainer() {
         this(0," "," ");
    }

    public String getSpecialization() {
        return Specialization;
    }

    public void setSpecialization(String Specialization) {
        this.Specialization = Specialization;
    }

  
    @Override
    public String toString() {
        return String.format ("%s The Specialization : %s \n ",super.toString(),getSpecialization());
    }
}

