
public class Premium extends Member {
     private Trainer trainer;

    public Premium(Trainer trainer, int hight, double weight, Date date, int phoneNum, int numOfRegistrations, double priceMonthly, int Id, String name, String status) {
        super(hight, weight, date, phoneNum, numOfRegistrations, priceMonthly, Id, name, status);
       setTrainer(trainer);
    }

   
   

     public Premium() {
      this(null,0,0.0,null,0,0,0.0,0,"","");
    }
     
  
    public Trainer getTrainer() {
        return trainer;
    }

    public void setTrainer(Trainer trainer) {
        this.trainer = trainer;
    }

    @Override
    public String toString() {
        return "Premium{" + "trainer=" + trainer + '}';
    }

    @Override
    public double calculate() {
        double total = getPriceMonthly();
        total += 250;

        return total * getDurationInMonth();

        return super.calculate(); 
    }   
        
    public boolean hasTrainer(){
        return true;
        
    }
    
    
     
     
}
   
    



    
