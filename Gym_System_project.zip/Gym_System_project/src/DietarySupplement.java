
public class DietarySupplement implements Pay{


private Item [] item ;

private double Price;

    public DietarySupplement(Item[] item, double Price) {
        this.item = item;
        this.Price = Price;
    }

    public Item[] getItem() {
        return item;
    }

    public double getPrice() {
        return Price;
    }

    public void setItem(Item[] item) {
        this.item = item;
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }







public DietarySupplement () { 
this (null,0.0);
}






public void Payable() {
double total = (Pay.VAT*Price)+Price;
System.out.println("total price = "+ total );

}

@Override

public String toString() {

return "DietarySupplement{ " + "item=" + item + ", Price=" + Price + '}'; }
public class Item {

private String name;

private int amount;

private String dwscription;

public Item (String name, int amount, String dwscription) {

this.name = name;

this.amount = amount;

this.dwscription = dwscription;

}

public Item() {
this ("" ,0,"");
}



public String getName() {

return name;

}

public void setName (String name) {

this.name = name;

}

public int getAmount () {

return amount; }

public void setAmount (int amount) {

this.amount = amount;

}
public String getDwscription() {

return dwscription;

}

public void setDwscription (String dwscription) {

this.dwscription = dwscription;

}

@Override

public String toString() {

return "Item(" + "name=" + name + ", amount=" + amount + ", dwscription=" + dwscription + '}';
}

}

}
