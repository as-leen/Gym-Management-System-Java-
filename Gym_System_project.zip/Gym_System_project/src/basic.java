
public class basic extends Member  {
    
    private int AccessTime;

    public basic(int AccessTime, int hight, double weight, Date date, int phoneNum, int numOfRegistrations, double priceMonthly, int Id, String name, String status) {
        super(hight, weight, date, phoneNum, numOfRegistrations, priceMonthly, Id, name, status);
        setAccessTime(AccessTime);
    }
   
    public basic(){
        this(0,0,0.0,null,0,0,0.0,0,"","");
        
    }
    

    public basic(int AccessTime) {
        this.AccessTime = AccessTime;
    }
    

    public int getAccessTime() {
        return AccessTime;
    }

    public void setAccessTime(int AccessTime) {
        this.AccessTime = AccessTime;
    }

    @Override
    public double calculate() {
        
        double total = getPriceMonthly();
        total += 100;

        return total * getDurationInMonth();

    }

    @Override
    public String toString() {
        return "basic{" + "AccessTime=" + AccessTime + '}';
    }
    
    
    
    
    

    }
    
    
    

