
public abstract class Member extends Person implements Pay {

    private int hight;
    private double weight;
    private Date date;
    private int phoneNum;
    private int numOfRegistrations;
    private double priceMonthly;
    private static double total;
private String status;


    public Member(int hight, double weight, Date date, int phoneNum, int numOfRegistrations, double priceMonthly, int Id, String name,String status) {
        super(Id, name);
       setHight(hight);
        setWeight(weight);
        setDate(date);
        setPhoneNum(phoneNum);
        setPriceMonthly(priceMonthly);
        setNumOfRegistrations(numOfRegistrations);
        total++;
         setStatus( status) ;
        
    }

  
    public Member(){
        this(0,0.0,null,0,0,0.0,0,"","");
    }

    
    

    

    @Override
    public void Payable() {
      

      
    }

    public final void ModifiedRegistration() {
        setStatus("Modified ");

        System.out.println("Registration has been modefied successfully.");


    }

    public final void ConfirmRegistration() {
        setStatus("Confirmed");

        System.out.println("Registration has been confirmed successfully.");


    }

    public final void WithOffer() {
        if (this.getClass().getSimpleName().equals("PremiumMembership") &&  > 2500) {
            System.out.println("Offer can be applied");
        } else {
            System.out.println("Offer can not be applied");
        }

        
    }
    
public abstract double calculate();

    public static void setTotal(double total) {
        Member.total = total;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public static double getTotal() {
        return total;
    }

    public String getStatus() {
        return status;
    }
    
       
    
     


    public int getNumOfRegistrations() {
        return numOfRegistrations;
    }

    public void setNumOfRegistrations(int numOfRegistrations) {
        this.numOfRegistrations = numOfRegistrations;
    }

    

    public int getHight() {
        return hight;
    }

    public double getWeight() {
        return weight;
    }

    public Date getDate() {
        return date;
    }

    public int getPhoneNum() {
        return phoneNum;
    }

    public double getPriceMonthly() {
        return priceMonthly;
    }

    public void setHight(int hight) {
        this.hight = hight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setPhoneNum(int phoneNum) {
        this.phoneNum = phoneNum;
    }

    public void setPriceMonthly(double priceMonthly) {
        this.priceMonthly = priceMonthly;
    }

    @Override
    public String toString() {
        return "Member{" + "hight=" + hight + ", weight=" + weight + ", date=" + date + ", phoneNum=" + phoneNum + ", numOfRegistrations=" + numOfRegistrations + ", priceMonthly=" + priceMonthly + '}';
    }

   

    
}