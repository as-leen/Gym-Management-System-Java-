

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {





    static ArrayList<Member> list = new ArrayList<Member>();
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int choice = 0;
        fillList();
        System.out.println("*** WELCOME TO GYM SYSTEM ***");
        do {
            try{
                menu();
                choice = input.nextInt();
                switch (choice) {

                    case 1://Add Subscription
                        System.out.print("1. Basic Membership \n"
                                + "2. Premium Membership \n"
                                
                                + "Select type of the membership to add >> ");
                        int subscriptionType = input.nextInt();

                        if (subscriptionType < 1 || subscriptionType > 3) {
                            System.out.println("Invalid choice.");
                        } else {

                            Member member ;
                            System.out.print("Enter subscription id: ");
                            String subscriptionId = input.next();
                            input.nextLine();
                            System.out.print("Enter subscription name: ");
                            String name = input.nextLine();
                            System.out.print("Enter price per month:");
                            double pricePerMonth = input.nextDouble();

                            System.out.print("How many benefits you want added? ");

                            int numberBenefits = input.nextInt();
                            Benefit[] benefits = new Benefit[numberBenefits];

                            // Benefit(String benefitId, String description)
                            for (int i = 0; i < benefits.length; i++) {
                                input.nextLine();
                                System.out.print("Enter benefit id: ");
                                String id = input.next();
                                System.out.println("Enter benefit name: ");
                                String benefitName = input.next();
                                input.nextLine();
                                System.out.print("Enter description: ");
                                String description = input.nextLine();
                                benefits[i] = new Benefit(id, benefitName, description);

                            }

                            System.out.print("Enter duration in month: ");
                            int durationInMonth = input.nextInt();
                            //if or switch
                            if (subscriptionType == 1) {
                                System.out.print("Enter max GYM accesstimes: ");
                                int maxAcc = input.nextInt();
                                subscription = new BasicSubscription(subscriptionId, name, pricePerMonth, benefits, durationInMonth, maxAcc);
                            } else if (subscriptionType == 2) {
                                System.out.print("Enter additional perks: ");
                                String additionalPerks = input.nextLine();
                                subscription = new PremiumSubscription(subscriptionId, name, pricePerMonth, benefits, durationInMonth, additionalPerks);
                            } else {
                                //Trainer(String trainerId, String name, String mainSpecialization, int ID)
                                System.out.print("Enter trainerId: ");
                                int trainerId = input.nextInt();

                                System.out.print("Enter trainer name: ");
                                String trainerName = input.nextLine();
                                System.out.println("Enter main specialization: ");
                                String mainSpecialization = input.nextLine();

                                subscription = new VIPSubscription(subscriptionId, name, pricePerMonth, benefits, durationInMonth, new Trainer(trainerId, name, mainSpecialization));
                            }
                            list.add(subscription);
                            System.out.println("subscription has been added to the list.");
                        }//end else
                        break;

                    case 2://Remove subscription
                        System.out.print("Enter subscription id to remove: ");
                        String subscriptionId = input.next();
                        boolean removed = false;
                        for (int i = 0; i < list.size(); i++) {
                            Subscription ele = list.get(i);
                            if (ele.getSubscriptionId().equals(subscriptionId)) {
                                list.remove(i);
                                removed = true;
                                break;
                            }
                        }//end loop
                        if (removed) {
                            System.out.println("Subscription with id " + subscriptionId + " has been removed.");
                        } else {
                            System.out.println("No subscription with id " + subscriptionId + " is found.");
                        }
                        break;

                    

                    
                        }
                        if (!isFound) {
                            System.out.println("Invalid Member id!");
                            continue;
                        }
                        //end while loop
                        System.out.println("Enter Registration date:");
                        System.out.print("year: ");
                        int year = input.nextInt();
                        if (year < 2024) {
                            System.out.println("Invalid year.");
                            continue;
                        }
                        System.out.print("month: ");
                        int month = input.nextInt();
                        if (month < 1 || month > 12) {
                            System.out.println("Invalid month.");
                            continue;
                        }
                        System.out.print("day: ");
                        int day = input.nextInt();
                        if (day < 1 || day > 31) {
                            System.out.println("Invalid day.");
                            continue;
                        }

                        Date date = new Date(year, month, day);
                        //read Trainee info
                        System.out.print("Enter your id: ");
                        int id = input.nextInt();
                        input.nextLine();
                        System.out.print("Enter your name: ");
                        String name = input.nextLine();
                        System.out.print("Enter phone number: ");
                        String phoneNum = input.next();

                        System.out.print("Enter Height: ");
                        int height = input.nextInt();

                        System.out.print("Enter weight: ");
                        int weight = input.nextInt();

                        //create objects for Trainee and  Registration
                        Trainer t = new Trainer( Id,name, Specialization );
                        

                        System.out.print("Confirm Registration? (Y/N): ");
                        char answer = input.next().charAt(0);
                        if (answer == 'y' || answer == 'Y') {
                            registration.confirmRegistration();
                            registrations.add(registration);
                            registration.printInfo();
                        } else {
                            System.out.println("Your registration has been cancelled!");
                        }
                        break;

                    case 5://Show registration
                        System.out.print("Enter registration number: ");
                        int registrationNumber = input.nextInt();
                        boolean found = false;
                        for (Registration ele : registrations) {
                            if (ele.getId() == registrationNumber) {
                                System.out.println(ele);
                                found = true;
                            }
                        }//end loop
                        if (found == false) {
                            System.out.println("Registration with number " + registrationNumber + " not found");
                        }
                        break;

                    case 6://Cancel registration
                        System.out.print("Enter registration id: ");
                        registrationNumber = input.nextInt();
                        found = false;
                        for (Registration ele : registrations) {
                            if (ele.getId() == registrationNumber) {
                                ele.cancelRegistration();
                                System.out.println(ele);
                                found = true;
                            }
                        }
                        if (found == false) {
                            System.out.println("Registration with id " + registrationNumber + " is not found");
                        }
                        break;

                    case 7:
                        ArrayList<DietarySupplement> dietarySupplements = new ArrayList<>();
diterySupplement.add(new DietarySupplement("protin powder"))
                        
                        //show the list
                        for (int i = 0; i < dietarySupplements.size(); i++) {
                            System.out.println(i + "-" + dietarySupplements.get(i));
                            System.out.println("----------------");
                        }
                        System.out.print("Enter the item index:");
                        int index = input.nextInt();
                        if (index < 0 || index >= dietarySupplements.size()) {
                            System.out.println("invalid index");
                            continue;
                        }

                        DietarySupplement item = dietarySupplements.get(index);

                        System.out.println(item);

                        item.Payable();
                        System.out.println("Thanks for the order!");

                        break;

                    case 8://GUI
                        //GUI.main(null); //calling static method
                        break;

                    case 9://Read from text file
                        ReadText rt = new ReadText();
                        rt.openTextFile("subscription.txt");
                        rt.readFromFile();
                        rt.closeFile();
                        break;

                    case 10://Save/Write to text file
                        WriteText wf = new WriteText();
                        wf.openTextFile("subscription.txt");
                        if (list.isEmpty()) {
                            System.out.println("No orders yet.");
                        } else {
                            for (Subscription ele : list) {
                                wf.writeToFile(ele);
                            }
                        }
                        wf.closeFile();
                        System.out.println("All orders saved to the text file orders.txt");
                        break;

                    case 11://Exit
                        System.out.println("Thank you for using our system.\nHave a nice day.");
                        break;
                    default:
                        System.out.println("Invalid Choice!");
                }
            } catch (InputMismatchException ex) {
                System.err.println("Invalid input");
                input.nextLine();
            } catch (NullPointerException ex) {
                System.err.println(ex);
            } catch (ClassCastException ex) {
                System.err.println(ex);
            } catch (ArrayIndexOutOfBoundsException ex) {
                System.err.println(ex);
            } catch (Exception ex) {
                System.err.println(ex);
            }
        } while (choice != 11);

    }

    public static void menu() {
        System.out.print("\n1. Add Membership . \n"
                + "2. Remove Membership .  .\n"
                + "3. Display Membership.\n"
                + "4. Order Dietary Supplement \n"
                + "5. GUI.\n"
                + "6. Read From File.\n"
                + "7.Save Orders.\n"
                + "8.Exit.\n"
                + ">> ");
    }

   


}   

