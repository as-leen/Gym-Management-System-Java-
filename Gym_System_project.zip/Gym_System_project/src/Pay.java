
interface Pay {
  
    public static final double VAT= 0.15;

public abstract void Payable();
}
