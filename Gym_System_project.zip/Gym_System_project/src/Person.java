

public abstract class Person {
    
    private int Id;
    private String name ;

    public Person(int Id, String name) {
       setId( Id);
       setName( name);
    }

    public Person() {
        this(0," ");
    }
    

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return String.format ("ID : %d \nName : %s \n",getId(),getName());
    }
    
    
}




